package com.reuse.spark

import org.apache.spark.SparkContext
import org.apache.spark.sql.functions.{col, lit, when}
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession

object sapientExercise {
def main(args: Array[String]) {

//Create conf object
val conf = new SparkConf().setMaster("local")
.setAppName("Sapient Exercise")

//create spark context object
val sc = new SparkContext(conf)
val spark = SparkSession.builder.config(sc.getConf).getOrCreate()

val filepath = "C:\\Users\\achandhrasekar\\Desktop\\sapient\\sampleData\\question1.txt"

val raw_df = spark.read.option("delimiter","\t").option("header","true").csv(filepath)
raw_df.createOrReplaceTempView("raw_table");

spark.sql("select Name, Age, Location from (select Name, Age, Location, row_number() over(partition by Name, Age order by 1) as latest_rec from raw_table) x where x.latest_rec = 1").show

sc.stop
}
}