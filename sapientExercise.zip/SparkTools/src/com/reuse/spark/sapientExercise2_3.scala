package com.reuse.spark

import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.Row
import org.apache.spark.sql.types._
import org.apache.spark.sql.hive.HiveContext

object sapientExercise2_3 {
def main(args: Array[String]) {

//Create conf object
val conf = new SparkConf().setMaster("local")
.setAppName("Sapient Exercise")

//create spark context object
val sc = new SparkContext(conf)
val hiveContext = new HiveContext(sc)
val spark = SparkSession.builder.config(sc.getConf).getOrCreate()


val user_clickstreamRDD = sc.parallelize(Seq(Row("2018-01-01T11:00:00Z", "u1"),Row("2018-01-01T12:00:00Z", "u1"),Row("2018-01-01T11:00:00Z", "u2"),Row("2018-01-02T11:00:00Z", "u2"),Row("2018-01-01T12:15:00Z", "u1")))

hiveContext.sql("CREATE TABLE IF NOT EXISTS user_clickstream ( timestampAttribute String, userid String) ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' LINES TERMINATED BY '\n' STORED AS TEXTFILE")

val emptyDataFrame = hiveContext.sql("select * from user_clickstream limit 0")

val user_clickstreamDataFrame = hiveContext.createDataFrame(user_clickstreamRDD, emptyDataFrame.schema)

val user_clickstreamData_updated = user_clickstreamDataFrame.withColumn("timestampAttribute1", unix_timestamp($"timestampAttribute", "yyyy-MM-dd'T'HH:mm:ss'Z'").cast(TimestampType))

user_clickstreamData_updated.registerTempTable("user_clickstream")

val question2Result = hiveContext.sql("select timestampAttribute, timestampAttribute1, userid, COALESCE(time_diff,0) as time_diff, sum(time_diff_flag) over(partition by userid order by timestampAttribute) as sessionvalue, concat(userid,sum(time_diff_flag) over(partition by userid order by timestampAttribute)) as session_Id from ( select  timestampAttribute, userid, timestampAttribute1, ( unix_timestamp(timestampAttribute1) - unix_timestamp(lag(timestampAttribute1,1) over(partition by userid order by timestampAttribute1))) /60 as time_diff, case when (( unix_timestamp(timestampAttribute1) - unix_timestamp(lag(timestampAttribute1,1) over(partition by userid order by timestampAttribute1))) /60) >= 30 then 1 else 0 end as time_diff_flag from user_clickstream )x group by timestampAttribute, timestampAttribute1, userid, time_diff, time_diff_flag")
question2Result.show

question2Result.createOrReplaceTempView("question2ResultTable");


hiveContext.sql("SET hive.exec.dynamic.partition=true")
hiveContext.sql("SET hive.exec.dynamic.partition.mode=nonstrict")

hiveContext.sql("CREATE TABLE IF NOT EXISTS user_clickstream_partitionTable ( timestampattribute String, userid String, time_diff int, session_Id string ) partitioned by (timestampattribute1 date) ")

hiveContext.sql("INSERT into table user_clickstream_partitionTable PARTITION(timestampattribute1) select timestampattribute,userid,time_diff, session_Id, cast(from_unixtime(unix_timestamp(substr(timestampattribute1,1,10) , 'yyyy-MM-dd')) as date) as timestampattribute1 from question2ResultTable ")

hiveContext.sql("select timestampattribute1, count(distinct session_Id) as Number_of_sessions_generated_day  from user_clickstream_partitionTable group by timestampattribute1 ").show

hiveContext.sql("select userid, timestampattribute1, sum(time_diff) as Total_time_spent_user__day  from user_clickstream_partitionTable group by userid,timestampattribute1 ").show

hiveContext.sql("select userid,month(timestampattribute1) as month, sum(time_diff) as Total_time_spent_by_a_user_over_month from user_clickstream_partitionTable group by userid,month(timestampattribute1)").show




}
}